﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KYCServices.Controllers
{
    public class Contact
    {
        public string Name { get; set; }
        public int ID { get; set; }
        public string Content { get; set; }
    }
    [Authorize]
    public class ValuesController : ApiController
    {
        private const string content = @"Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
            Fusce dapibus enim ac vulputate mattis. Nulla viverra elit vitae orci vehicula, efficitur ullamcorper urna elementum. Quisque aliquet nisi suscipit, blandit nisi ac, facilisis nunc. Phasellus a aliquam ligula. Curabitur at vulputate sem. Sed suscipit faucibus lorem, sit amet dictum ex viverra eu. Ut tincidunt libero vitae purus porta, nec lobortis augue ornare. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Duis a aliquam elit. Curabitur in fringilla augue, et eleifend tellus. In hac habitasse platea dictumst.
            Sed et maximus purus, <a href='google.com'>test</a> vel facilisis leo.Nulla facilisi.Nam rutrum rutrum felis, consectetur tincidunt odio tincidunt ac.Ut mollis egestas lectus, eu luctus tellus varius a.Sed viverra viverra justo, sed faucibus dolor.Sed consequat commodo consequat. Donec eget sodales augue, id tincidunt magna.Cras quis ipsum varius neque commodo iaculis.Curabitur pretium ligula elit, nec laoreet lacus sagittis ut.Aenean varius viverra ultrices. Phasellus porta felis nec quam dictum, sit amet dignissim risus ullamcorper.Nunc nisl felis, condimentum id nisi in, pulvinar tempus augue.Nullam consequat commodo eros, faucibus maximus elit vehicula nec.Praesent lobortis ligula a augue dapibus, et mattis nibh posuere.
            Ut et velit augue. <b>Fusce sed neque scelerisque, bibendum metus vitae, </b>porttitor ipsum. Donec non arcu efficitur, suscipit nunc ut, maximus mi. Suspendisse purus sapien, rhoncus ac dui vestibulum, auctor aliquet tellus.Proin dignissim luctus tincidunt. Sed a lectus tristique elit molestie venenatis ac id urna. Aenean et quam et ipsum dignissim cursus non nec libero. Quisque eu massa turpis. In laoreet urna libero, sed placerat sem faucibus et.Sed vel libero vehicula, facilisis mauris at, porta quam. Proin quis lectus congue, finibus magna quis, fringilla ligula. Morbi nibh risus, tempus sit amet augue eget, fermentum facilisis odio.Vivamus et lectus non sapien eleifend dictum nec eget ante. Vestibulum ut dui sagittis, consequat est id, consequat risus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
            Aliquam pharetra tortor sit amet auctor fringilla.In accumsan finibus nisi, sit amet volutpat leo. Phasellus sed urna nibh. Nulla aliquet nisl sapien, at tempus neque convallis non.Phasellus consectetur est non est efficitur, quis cursus urna aliquam. Fusce malesuada ac tellus eget facilisis. Vivamus non tortor nec lorem placerat condimentum.Aliquam ac est iaculis eros convallis egestas vitae id quam. Praesent congue luctus velit. Nunc in fringilla massa. Aenean bibendum mi ac neque consequat consequat.Donec suscipit libero vel consequat lobortis. Cras sagittis feugiat augue sit amet facilisis.In vestibulum efficitur elit eget bibendum. Nam ultricies mauris sed sollicitudin pharetra. Fusce sed maximus eros, sed sagittis arcu.
            ";
        // GET api/values
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}
        public IEnumerable<Contact> Get()
        {
            var contacts = Enumerable.Range(1, 100).Select(i =>
             new Contact
             {
                 ID = 1, Name = $"Contact - {i}", Content = content
             }
            );
            return contacts;
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
