﻿var config = {
  dataProvider:{
    serviceUrl: "http://localhost:1212/api/"
  }
}
