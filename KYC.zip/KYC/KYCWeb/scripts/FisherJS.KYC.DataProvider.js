﻿/// <reference path="jquery-2.2.2.js" />

if (typeof (FisherJS) == "undefined")
{ FisherJS = { __namespace: true }; }

if (FisherJS.KYC === undefined)
{ FisherJS.KYC = {} }

FisherJS.KYC.DataProvider = function (opts) {
	opts = opts || {};
	opts.params = opts.params || {};
	opts.callback = opts.callback || function () { };
	if (!opts.serviceUrl) {
		throw "serviceUrl not specified";
	}
	//.id = opts.id || 1;
	//ref:http://stackoverflow.com/questions/1529077/handling-optional-parameters-in-javascript
	//ref:http://stackoverflow.com/questions/2559318/how-to-check-for-an-undefined-or-null-variable-in-javascript
	function getJSON(urlToInvoke,onData,onError) {
		        $.ajax(
						{
						    url: urlToInvoke,
							contentType:"application/json",
							method:"GET"
						})
					  .done(function (data) {
					      if (onData) {
					          onData(data);
					      }
  						//alert("success");
					  })
					  .fail(function (jqXHR, textStatus, errorThrown) {
					      console.log(errorThrown);
					      if (onError) {
					          oneError(errorThrown);
                          }
					  })
					  .always(function (data) {
  						//alert("complete");
					  });
	}
	GET = function (url,onData) {
		var urlToInvoke = opts.serviceUrl + url;
		console.log(urlToInvoke);
		getJSON(urlToInvoke,onData);
	},

	POST = function (url, payload) {
		if (!payload) {
			throw "payload must be specified";
		}
		var url = opts.serviceUrl + url;
		console.log(url);
	};

	return {
		GET: GET,
		POST: POST
	};
};