﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace PizzaOrdering
{
    public class Pizza
    {
        public string[] Toppings
        {
            get;
            set;
        }
    }

    public class PizzaComparer : IEqualityComparer<Pizza>
    {


        public bool Equals(Pizza x, Pizza y)
        {
            if (object.ReferenceEquals(x, y))
            {
                return true;
            }
            if (x == null || y == null)
            {
                return false;
            }
            if(x.Toppings.Length != y.Toppings.Length)
            {
                return false;
            }
            var result = x.Toppings.OrderBy(t => t).SequenceEqual(y.Toppings.OrderBy(t => t));
            return result;
        }

        public int GetHashCode(Pizza obj)
        {
            var hash = string.Concat(obj.Toppings,"").GetHashCode();
            return hash;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            var content = File.ReadAllText("pizzas.json");
            Pizza[] pizzas = JsonConvert.DeserializeObject<Pizza[]>(content);
            var orderedPizzas = pizzas.GroupBy(p => p, p => p.Toppings,new PizzaComparer())
                               .Select(x => new{ Pizza = x.Key, Count = x.Count()})
                               .OrderByDescending(x => x.Count);
            var messages = orderedPizzas.Take(20)
                                 .Select(x => string.Format("Pizza with Toppings:{0} ordered {1} times",
                                                            string.Join(",", x.Pizza.Toppings), x.Count));
            string s = string.Join(Environment.NewLine, messages);
            Console.WriteLine(s);
        }
    }
}
